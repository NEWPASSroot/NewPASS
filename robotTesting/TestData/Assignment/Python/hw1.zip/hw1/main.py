def add(a, b):
    return a + b

def sub(a, b):
    return a - b

def mul(a, b):
    return a * b

def maxNum(a, b):
    if a > b:
        return a
    return b

minimum = lambda a, b: a if a < b else b
